
setblock ~ ~ ~ cake