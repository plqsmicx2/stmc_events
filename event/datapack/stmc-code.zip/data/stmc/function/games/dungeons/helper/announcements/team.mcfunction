# get points & rankings
function stmc:games/dungeons/points/calculate_rankings
function stmc:games/dungeons/points/point_update

# Team scores

tellraw @a {text:"Team scores:",color:white}

$execute if score RED_RACCOONS dungeons.points.team.rank matches 1 run tellraw @a [{text:"#1: ",color:yellow},{text:"$(redName)",color:red},{text:" - ",color:yellow},{score:{name:"RED_RACCOONS",objective:"dungeons.points.team"}}]
$execute if score ORANGE_OTTERS dungeons.points.team.rank matches 1 run tellraw @a [{text:"#1: ",color:yellow},{text:"$(orangeName)",color:gold},{text:" - ",color:yellow},{score:{name:"ORANGE_OTTERS",objective:"dungeons.points.team"}}]
$execute if score PINK_PIKAS dungeons.points.team.rank matches 1 run tellraw @a [{text:"#1: ",color:yellow},{text:"$(pinkName)",color:light_purple},{text:" - ",color:yellow},{score:{name:"PINK_PIKAS",objective:"dungeons.points.team"}}]
$execute if score GREEN_GOATS dungeons.points.team.rank matches 1 run tellraw @a [{text:"#1: ",color:yellow},{text:"$(greenName)",color:green},{text:" - ",color:yellow},{score:{name:"GREEN_GOATS",objective:"dungeons.points.team"}}]
$execute if score CYAN_COUGARS dungeons.points.team.rank matches 1 run tellraw @a [{text:"#1: ",color:yellow},{text:"$(cyanName)",color:dark_aqua},{text:" - ",color:yellow},{score:{name:"CYAN_COUGARS",objective:"dungeons.points.team"}}]
$execute if score PURPLE_PENGUINS dungeons.points.team.rank matches 1 run tellraw @a [{text:"#1: ",color:yellow},{text:"$(purpleName)",color:dark_purple},{text:" - ",color:yellow},{score:{name:"PURPLE_PENGUINS",objective:"dungeons.points.team"}}]
$execute if score YELLOW_YAKS dungeons.points.team.rank matches 1 run tellraw @a [{text:"#1: ",color:yellow},{text:"$(yellowName)",color:yellow},{text:" - ",color:yellow},{score:{name:"YELLOW_YAKS",objective:"dungeons.points.team"}}]
$execute if score BLUE_BEARS dungeons.points.team.rank matches 1 run tellraw @a [{text:"#1: ",color:yellow},{text:"$(blueName)",color:blue},{text:" - ",color:yellow},{score:{name:"BLUE_BEARS",objective:"dungeons.points.team"}}]

$execute if score RED_RACCOONS dungeons.points.team.rank matches 2 run tellraw @a [{text:"#2: ",color:yellow},{text:"$(redName)",color:red},{text:" - ",color:yellow},{score:{name:"RED_RACCOONS",objective:"dungeons.points.team"}}]
$execute if score ORANGE_OTTERS dungeons.points.team.rank matches 2 run tellraw @a [{text:"#2: ",color:yellow},{text:"$(orangeName)",color:gold},{text:" - ",color:yellow},{score:{name:"ORANGE_OTTERS",objective:"dungeons.points.team"}}]
$execute if score PINK_PIKAS dungeons.points.team.rank matches 2 run tellraw @a [{text:"#2: ",color:yellow},{text:"$(pinkName)",color:light_purple},{text:" - ",color:yellow},{score:{name:"PINK_PIKAS",objective:"dungeons.points.team"}}]
$execute if score GREEN_GOATS dungeons.points.team.rank matches 2 run tellraw @a [{text:"#2: ",color:yellow},{text:"$(greenName)",color:green},{text:" - ",color:yellow},{score:{name:"GREEN_GOATS",objective:"dungeons.points.team"}}]
$execute if score CYAN_COUGARS dungeons.points.team.rank matches 2 run tellraw @a [{text:"#2: ",color:yellow},{text:"$(cyanName)",color:dark_aqua},{text:" - ",color:yellow},{score:{name:"CYAN_COUGARS",objective:"dungeons.points.team"}}]
$execute if score PURPLE_PENGUINS dungeons.points.team.rank matches 2 run tellraw @a [{text:"#2: ",color:yellow},{text:"$(purpleName)",color:dark_purple},{text:" - ",color:yellow},{score:{name:"PURPLE_PENGUINS",objective:"dungeons.points.team"}}]
$execute if score YELLOW_YAKS dungeons.points.team.rank matches 2 run tellraw @a [{text:"#2: ",color:yellow},{text:"$(yellowName)",color:yellow},{text:" - ",color:yellow},{score:{name:"YELLOW_YAKS",objective:"dungeons.points.team"}}]
$execute if score BLUE_BEARS dungeons.points.team.rank matches 2 run tellraw @a [{text:"#2: ",color:yellow},{text:"$(blueName)",color:blue},{text:" - ",color:yellow},{score:{name:"BLUE_BEARS",objective:"dungeons.points.team"}}]

$execute if score RED_RACCOONS dungeons.points.team.rank matches 3 run tellraw @a [{text:"#3: ",color:yellow},{text:"$(redName)",color:red},{text:" - ",color:yellow},{score:{name:"RED_RACCOONS",objective:"dungeons.points.team"}}]
$execute if score ORANGE_OTTERS dungeons.points.team.rank matches 3 run tellraw @a [{text:"#3: ",color:yellow},{text:"$(orangeName)",color:gold},{text:" - ",color:yellow},{score:{name:"ORANGE_OTTERS",objective:"dungeons.points.team"}}]
$execute if score PINK_PIKAS dungeons.points.team.rank matches 3 run tellraw @a [{text:"#3: ",color:yellow},{text:"$(pinkName)",color:light_purple},{text:" - ",color:yellow},{score:{name:"PINK_PIKAS",objective:"dungeons.points.team"}}]
$execute if score GREEN_GOATS dungeons.points.team.rank matches 3 run tellraw @a [{text:"#3: ",color:yellow},{text:"$(greenName)",color:green},{text:" - ",color:yellow},{score:{name:"GREEN_GOATS",objective:"dungeons.points.team"}}]
$execute if score CYAN_COUGARS dungeons.points.team.rank matches 3 run tellraw @a [{text:"#3: ",color:yellow},{text:"$(cyanName)",color:dark_aqua},{text:" - ",color:yellow},{score:{name:"CYAN_COUGARS",objective:"dungeons.points.team"}}]
$execute if score PURPLE_PENGUINS dungeons.points.team.rank matches 3 run tellraw @a [{text:"#3: ",color:yellow},{text:"$(purpleName)",color:dark_purple},{text:" - ",color:yellow},{score:{name:"PURPLE_PENGUINS",objective:"dungeons.points.team"}}]
$execute if score YELLOW_YAKS dungeons.points.team.rank matches 3 run tellraw @a [{text:"#3: ",color:yellow},{text:"$(yellowName)",color:yellow},{text:" - ",color:yellow},{score:{name:"YELLOW_YAKS",objective:"dungeons.points.team"}}]
$execute if score BLUE_BEARS dungeons.points.team.rank matches 3 run tellraw @a [{text:"#3: ",color:yellow},{text:"$(blueName)",color:blue},{text:" - ",color:yellow},{score:{name:"BLUE_BEARS",objective:"dungeons.points.team"}}]

$execute if score RED_RACCOONS dungeons.points.team.rank matches 4 run tellraw @a [{text:"#4: ",color:yellow},{text:"$(redName)",color:red},{text:" - ",color:yellow},{score:{name:"RED_RACCOONS",objective:"dungeons.points.team"}}]
$execute if score ORANGE_OTTERS dungeons.points.team.rank matches 4 run tellraw @a [{text:"#4: ",color:yellow},{text:"$(orangeName)",color:gold},{text:" - ",color:yellow},{score:{name:"ORANGE_OTTERS",objective:"dungeons.points.team"}}]
$execute if score PINK_PIKAS dungeons.points.team.rank matches 4 run tellraw @a [{text:"#4: ",color:yellow},{text:"$(pinkName)",color:light_purple},{text:" - ",color:yellow},{score:{name:"PINK_PIKAS",objective:"dungeons.points.team"}}]
$execute if score GREEN_GOATS dungeons.points.team.rank matches 4 run tellraw @a [{text:"#4: ",color:yellow},{text:"$(greenName)",color:green},{text:" - ",color:yellow},{score:{name:"GREEN_GOATS",objective:"dungeons.points.team"}}]
$execute if score CYAN_COUGARS dungeons.points.team.rank matches 4 run tellraw @a [{text:"#4: ",color:yellow},{text:"$(cyanName)",color:dark_aqua},{text:" - ",color:yellow},{score:{name:"CYAN_COUGARS",objective:"dungeons.points.team"}}]
$execute if score PURPLE_PENGUINS dungeons.points.team.rank matches 4 run tellraw @a [{text:"#4: ",color:yellow},{text:"$(purpleName)",color:dark_purple},{text:" - ",color:yellow},{score:{name:"PURPLE_PENGUINS",objective:"dungeons.points.team"}}]
$execute if score YELLOW_YAKS dungeons.points.team.rank matches 4 run tellraw @a [{text:"#4: ",color:yellow},{text:"$(yellowName)",color:yellow},{text:" - ",color:yellow},{score:{name:"YELLOW_YAKS",objective:"dungeons.points.team"}}]
$execute if score BLUE_BEARS dungeons.points.team.rank matches 4 run tellraw @a [{text:"#4: ",color:yellow},{text:"$(blueName)",color:blue},{text:" - ",color:yellow},{score:{name:"BLUE_BEARS",objective:"dungeons.points.team"}}]

$execute if score RED_RACCOONS dungeons.points.team.rank matches 5 run tellraw @a [{text:"#5: ",color:yellow},{text:"$(redName)",color:red},{text:" - ",color:yellow},{score:{name:"RED_RACCOONS",objective:"dungeons.points.team"}}]
$execute if score ORANGE_OTTERS dungeons.points.team.rank matches 5 run tellraw @a [{text:"#5: ",color:yellow},{text:"$(orangeName)",color:gold},{text:" - ",color:yellow},{score:{name:"ORANGE_OTTERS",objective:"dungeons.points.team"}}]
$execute if score PINK_PIKAS dungeons.points.team.rank matches 5 run tellraw @a [{text:"#5: ",color:yellow},{text:"$(pinkName)",color:light_purple},{text:" - ",color:yellow},{score:{name:"PINK_PIKAS",objective:"dungeons.points.team"}}]
$execute if score GREEN_GOATS dungeons.points.team.rank matches 5 run tellraw @a [{text:"#5: ",color:yellow},{text:"$(greenName)",color:green},{text:" - ",color:yellow},{score:{name:"GREEN_GOATS",objective:"dungeons.points.team"}}]
$execute if score CYAN_COUGARS dungeons.points.team.rank matches 5 run tellraw @a [{text:"#5: ",color:yellow},{text:"$(cyanName)",color:dark_aqua},{text:" - ",color:yellow},{score:{name:"CYAN_COUGARS",objective:"dungeons.points.team"}}]
$execute if score PURPLE_PENGUINS dungeons.points.team.rank matches 5 run tellraw @a [{text:"#5: ",color:yellow},{text:"$(purpleName)",color:dark_purple},{text:" - ",color:yellow},{score:{name:"PURPLE_PENGUINS",objective:"dungeons.points.team"}}]
$execute if score YELLOW_YAKS dungeons.points.team.rank matches 5 run tellraw @a [{text:"#5: ",color:yellow},{text:"$(yellowName)",color:yellow},{text:" - ",color:yellow},{score:{name:"YELLOW_YAKS",objective:"dungeons.points.team"}}]
$execute if score BLUE_BEARS dungeons.points.team.rank matches 5 run tellraw @a [{text:"#5: ",color:yellow},{text:"$(blueName)",color:blue},{text:" - ",color:yellow},{score:{name:"BLUE_BEARS",objective:"dungeons.points.team"}}]

$execute if score RED_RACCOONS dungeons.points.team.rank matches 6 run tellraw @a [{text:"#6: ",color:yellow},{text:"$(redName)",color:red},{text:" - ",color:yellow},{score:{name:"RED_RACCOONS",objective:"dungeons.points.team"}}]
$execute if score ORANGE_OTTERS dungeons.points.team.rank matches 6 run tellraw @a [{text:"#6: ",color:yellow},{text:"$(orangeName)",color:gold},{text:" - ",color:yellow},{score:{name:"ORANGE_OTTERS",objective:"dungeons.points.team"}}]
$execute if score PINK_PIKAS dungeons.points.team.rank matches 6 run tellraw @a [{text:"#6: ",color:yellow},{text:"$(pinkName)",color:light_purple},{text:" - ",color:yellow},{score:{name:"PINK_PIKAS",objective:"dungeons.points.team"}}]
$execute if score GREEN_GOATS dungeons.points.team.rank matches 6 run tellraw @a [{text:"#6: ",color:yellow},{text:"$(greenName)",color:green},{text:" - ",color:yellow},{score:{name:"GREEN_GOATS",objective:"dungeons.points.team"}}]
$execute if score CYAN_COUGARS dungeons.points.team.rank matches 6 run tellraw @a [{text:"#6: ",color:yellow},{text:"$(cyanName)",color:dark_aqua},{text:" - ",color:yellow},{score:{name:"CYAN_COUGARS",objective:"dungeons.points.team"}}]
$execute if score PURPLE_PENGUINS dungeons.points.team.rank matches 6 run tellraw @a [{text:"#6: ",color:yellow},{text:"$(purpleName)",color:dark_purple},{text:" - ",color:yellow},{score:{name:"PURPLE_PENGUINS",objective:"dungeons.points.team"}}]
$execute if score YELLOW_YAKS dungeons.points.team.rank matches 6 run tellraw @a [{text:"#6: ",color:yellow},{text:"$(yellowName)",color:yellow},{text:" - ",color:yellow},{score:{name:"YELLOW_YAKS",objective:"dungeons.points.team"}}]
$execute if score BLUE_BEARS dungeons.points.team.rank matches 6 run tellraw @a [{text:"#6: ",color:yellow},{text:"$(blueName)",color:blue},{text:" - ",color:yellow},{score:{name:"BLUE_BEARS",objective:"dungeons.points.team"}}]

$execute if score RED_RACCOONS dungeons.points.team.rank matches 7 run tellraw @a [{text:"#7: ",color:yellow},{text:"$(redName)",color:red},{text:" - ",color:yellow},{score:{name:"RED_RACCOONS",objective:"dungeons.points.team"}}]
$execute if score ORANGE_OTTERS dungeons.points.team.rank matches 7 run tellraw @a [{text:"#7: ",color:yellow},{text:"$(orangeName)",color:gold},{text:" - ",color:yellow},{score:{name:"ORANGE_OTTERS",objective:"dungeons.points.team"}}]
$execute if score PINK_PIKAS dungeons.points.team.rank matches 7 run tellraw @a [{text:"#7: ",color:yellow},{text:"$(pinkName)",color:light_purple},{text:" - ",color:yellow},{score:{name:"PINK_PIKAS",objective:"dungeons.points.team"}}]
$execute if score GREEN_GOATS dungeons.points.team.rank matches 7 run tellraw @a [{text:"#7: ",color:yellow},{text:"$(greenName)",color:green},{text:" - ",color:yellow},{score:{name:"GREEN_GOATS",objective:"dungeons.points.team"}}]
$execute if score CYAN_COUGARS dungeons.points.team.rank matches 7 run tellraw @a [{text:"#7: ",color:yellow},{text:"$(cyanName)",color:dark_aqua},{text:" - ",color:yellow},{score:{name:"CYAN_COUGARS",objective:"dungeons.points.team"}}]
$execute if score PURPLE_PENGUINS dungeons.points.team.rank matches 7 run tellraw @a [{text:"#7: ",color:yellow},{text:"$(purpleName)",color:dark_purple},{text:" - ",color:yellow},{score:{name:"PURPLE_PENGUINS",objective:"dungeons.points.team"}}]
$execute if score YELLOW_YAKS dungeons.points.team.rank matches 7 run tellraw @a [{text:"#7: ",color:yellow},{text:"$(yellowName)",color:yellow},{text:" - ",color:yellow},{score:{name:"YELLOW_YAKS",objective:"dungeons.points.team"}}]
$execute if score BLUE_BEARS dungeons.points.team.rank matches 7 run tellraw @a [{text:"#7: ",color:yellow},{text:"$(blueName)",color:blue},{text:" - ",color:yellow},{score:{name:"BLUE_BEARS",objective:"dungeons.points.team"}}]

$execute if score RED_RACCOONS dungeons.points.team.rank matches 8 run tellraw @a [{text:"#8: ",color:yellow},{text:"$(redName)",color:red},{text:" - ",color:yellow},{score:{name:"RED_RACCOONS",objective:"dungeons.points.team"}}]
$execute if score ORANGE_OTTERS dungeons.points.team.rank matches 8 run tellraw @a [{text:"#8: ",color:yellow},{text:"$(orangeName)",color:gold},{text:" - ",color:yellow},{score:{name:"ORANGE_OTTERS",objective:"dungeons.points.team"}}]
$execute if score PINK_PIKAS dungeons.points.team.rank matches 8 run tellraw @a [{text:"#8: ",color:yellow},{text:"$(pinkName)",color:light_purple},{text:" - ",color:yellow},{score:{name:"PINK_PIKAS",objective:"dungeons.points.team"}}]
$execute if score GREEN_GOATS dungeons.points.team.rank matches 8 run tellraw @a [{text:"#8: ",color:yellow},{text:"$(greenName)",color:green},{text:" - ",color:yellow},{score:{name:"GREEN_GOATS",objective:"dungeons.points.team"}}]
$execute if score CYAN_COUGARS dungeons.points.team.rank matches 8 run tellraw @a [{text:"#8: ",color:yellow},{text:"$(cyanName)",color:dark_aqua},{text:" - ",color:yellow},{score:{name:"CYAN_COUGARS",objective:"dungeons.points.team"}}]
$execute if score PURPLE_PENGUINS dungeons.points.team.rank matches 8 run tellraw @a [{text:"#8: ",color:yellow},{text:"$(purpleName)",color:dark_purple},{text:" - ",color:yellow},{score:{name:"PURPLE_PENGUINS",objective:"dungeons.points.team"}}]
$execute if score YELLOW_YAKS dungeons.points.team.rank matches 8 run tellraw @a [{text:"#8: ",color:yellow},{text:"$(yellowName)",color:yellow},{text:" - ",color:yellow},{score:{name:"YELLOW_YAKS",objective:"dungeons.points.team"}}]
$execute if score BLUE_BEARS dungeons.points.team.rank matches 8 run tellraw @a [{text:"#8: ",color:yellow},{text:"$(blueName)",color:blue},{text:" - ",color:yellow},{score:{name:"BLUE_BEARS",objective:"dungeons.points.team"}}]