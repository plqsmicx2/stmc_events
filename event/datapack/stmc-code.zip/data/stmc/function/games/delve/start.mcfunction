# this function runs whenever attempting to start the delve game
# the function will set the next game to delve
# then will increment the current event stage

# set next game to delve
execute if score stmc.handler event.stage matches 0 run scoreboard players set stmc.handler stats.game1 3
execute if score stmc.handler event.stage matches 2 run scoreboard players set stmc.handler stats.game2 3
execute if score stmc.handler event.stage matches 4 run scoreboard players set stmc.handler stats.game3 3
execute if score stmc.handler event.stage matches 6 run scoreboard players set stmc.handler stats.game4 3
execute if score stmc.handler event.stage matches 8 run scoreboard players set stmc.handler stats.game5 3
execute if score stmc.handler event.stage matches 10 run scoreboard players set stmc.handler stats.game6 3
execute if score stmc.handler event.stage matches 12 run scoreboard players set stmc.handler stats.game7 3
execute if score stmc.handler event.stage matches 14 run scoreboard players set stmc.handler stats.game8 3

# increment stage
scoreboard players add stmc.handler event.stage 1

# update lobby stage
scoreboard players reset lobby.handler lobby.stage

# run delve load function
function stmc:games/delve/load