# tick function for race

# stages:
# 0- delay1 (waiting for players)
# 1- explanation
# 2- delay2
# 3- game
# 4- delay4 (reset & point announcement)

# run functions every tick
execute if score extract.handler extract.stage matches 3..4 run function stmc:games/extract/points_update
function stmc:games/extract/sidebar with storage stmc:global

# determine players on a team
function stmc:games/extract/helper/player_count

# run automatic pause
execute unless score extract.handler extract.stage matches 3 run function stmc:thread/helper/automatic_pause

# if we're in stage 0, increment timer
execute if score extract.handler extract.stage matches 0 run scoreboard players add extract.handler extract.timer.delay1 1
execute if score extract.handler extract.stage matches 0 if score extract.handler extract.timer.delay1 matches 200.. run scoreboard players set extract.handler extract.stage 1
# add forceload
execute in stmc:extract if score extract.handler extract.timer.delay1 matches 100 run forceload add 350 75 -20 0

# if we're in stage 1, increment timer & run explanation
execute if score extract.handler extract.stage matches 1 run scoreboard players add extract.handler extract.timer.explanation 1
execute in stmc:extract if score extract.handler extract.stage matches 1 run function stmc:games/extract/explanation

# if we're in stage 2, increment timer & countdown at 5 seconds
execute if score extract.handler extract.stage matches 2 run scoreboard players add extract.handler extract.timer.delay2 1
# countdown
execute if score extract.handler extract.stage matches 2 if score extract.handler extract.timer.delay2 matches 100 run title @a actionbar {"text":"5 seconds!", "color":"red"}
execute if score extract.handler extract.stage matches 2 if score extract.handler extract.timer.delay2 matches 120 run title @a actionbar {"text":"4 seconds!", "color":"red"}
execute if score extract.handler extract.stage matches 2 if score extract.handler extract.timer.delay2 matches 140 run title @a actionbar {"text":"3 seconds!", "color":"red"}
execute if score extract.handler extract.stage matches 2 if score extract.handler extract.timer.delay2 matches 160 run title @a actionbar {"text":"2 seconds!", "color":"red"}
execute if score extract.handler extract.stage matches 2 if score extract.handler extract.timer.delay2 matches 180 run title @a actionbar {"text":"1 second!", "color":"red"}

execute if score extract.handler extract.stage matches 2 if score extract.handler extract.timer.delay2 matches 200.. run function stmc:games/extract/helper/game_start

# if we're in stage 3, increment timer & run game
execute if score extract.handler extract.stage matches 3 run scoreboard players add extract.handler extract.timer.game 1
execute if score extract.handler extract.stage matches 3 run function stmc:games/extract/game_tick

# if we're in stage 4, run reset & point announcement
execute if score extract.handler extract.stage matches 4 run scoreboard players add extract.handler extract.timer.delay3 1
execute if score extract.handler extract.stage matches 4 run function stmc:games/extract/points_announcement
execute if score extract.handler extract.stage matches 4 if score extract.handler extract.timer.delay3 matches 800.. run function stmc:games/extract/reset